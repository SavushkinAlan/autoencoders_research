from setuptools import setup

setup(name="autoencoder", packages=["src"], version="0.1")